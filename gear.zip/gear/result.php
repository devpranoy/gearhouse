<style>
.table { color:#7F7F7F; border-collapse:collapse}
.table,
.table caption { border-right:1px solid #CCC; border-left:1px solid #CCC}
.table caption,
.table th,
.table td { border-left:0; padding:10px}
.table caption,
.table thead th,
.table tfoot th,
.table tfoot td { background-color:#E63C1E; color:#FFF; font-weight:bold; text-transform:uppercase}
.table thead th { background-color:#C30; color:#FFB3A6; text-align:center}
.table tbody th { padding:20px 10px}
.table tbody tr.odd { background-color:#F7F7F7; color:#666}
.table tbody a { padding:1px 2px; color:#333; text-decoration:none; border-bottom:none}
.table tbody a:hover{ color:#000}
.table tbody tr:hover { background-color:#EEE; color:#333}
.table tbody tr:hover a { background-color:#FFF}
.table tbody td+td+td+td a { color:#C30; font-weight:bold; border-bottom:0}
.table tbody td+td+td+td a:active,
.table tbody td+td+td+td a:hover,
.table tbody td+td+td+td a:focus,
.table tbody td+td+td+td a:visited { color:#E63C1E}
</style>
<?php
echo "<h1>Welcome to Gear House !!!<h1>";
$catagory=$_COOKIE['catagory'];
$engine= $_COOKIE['engine'];
$type=$_COOKIE['type'];
$minm=$_GET['price-min'];
$maxm=$_GET['price-max'];
$maxm=$maxm*100000;
$minm=$minm*100000;
// search CAR 
$servername = "mysql.hostinger.in";
$username = "u769895625_cars";
$password = "2UGjQdqDm5L";
$dbname = "u769895625_gearb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); 
}

$sql = "SELECT link, name, catagory, engine, type , price FROM car WHERE catagory like '$catagory' and engine like '$engine' and type like '$type' and price between '$minm' and '$maxm'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo ' <table class="table" summary="Sample Table" style="width:100%;">
    <caption>
    Cars Under Your selection
    </caption>
    <thead>
    <tr><th>Car Name</th><th>Category</th><th>Engine </th><th>Car Type</th><th>Car Price</th></tr>
    </thead>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "
        <tbody>
        <tr>
        <td><a href=".$row["link"].">".$row["name"]."</a></td>
        <td>".$row["catagory"]." </td>
        <td> ".$row["engine"]."</td>
        <td> ".$row["type"]."</td>
        <td> ".$row["price"]."</td>
        </tr>
        </tbody>";
    }
    echo "
    <tfoot>
      <tr>
        <th >Total : </th>
        <td colspan='4' >$result->num_rows Cars</td>
      </tr>
    </table>";
} else {
    echo "Sorry No Cars Found !";
}
$conn->close();
?> 
